#!/usr/bin/env python3
"""生成知微教学平台统一风格 SVG Icon 图标集"""

import os

ICON_DIR = os.path.dirname(os.path.abspath(__file__))
SIZE = 24
COLOR = "#F0A040"  # 琥珀色主色
COLOR_SECONDARY = "#666666"

def svg_wrap(body, view_box="0 0 24 24", size=SIZE):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="{view_box}" fill="none" stroke="{COLOR}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
{body}
</svg>'''

def write_icon(name, svg):
    path = os.path.join(ICON_DIR, f"{name}.svg")
    with open(path, 'w') as f:
        f.write(svg)
    return f"{name}.svg"

icons = {}

# ============ 侧边栏导航 icon（18个）============
icons['home'] = svg_wrap('''
  <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
  <polyline points="9 22 9 12 15 12 15 22"/>
''')

icons['teaching-prep'] = svg_wrap('''
  <path d="M4 19.5A2.5 2.5 0 016.5 17H20"/>
  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/>
  <line x1="8" y1="7" x2="16" y2="7"/>
  <line x1="8" y1="11" x2="14" y2="11"/>
''')

icons['draft'] = svg_wrap('''
  <path d="M12 20h9"/>
  <path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
''')

icons['published'] = svg_wrap('''
  <path d="M4 19.5A2.5 2.5 0 016.5 17H20"/>
  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/>
  <polyline points="8 8 12 12 16 8"/>
''')

icons['material-library'] = svg_wrap('''
  <path d="M14.5 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V7.5L14.5 2z"/>
  <polyline points="14 2 14 8 20 8"/>
  <rect x="8" y="12" width="3" height="3" rx="0.5"/>
  <rect x="13" y="12" width="3" height="3" rx="0.5"/>
  <rect x="8" y="17" width="3" height="3" rx="0.5"/>
  <rect x="13" y="17" width="3" height="3" rx="0.5"/>
''')

icons['peer-review'] = svg_wrap('''
  <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4-4v2"/>
  <circle cx="9" cy="7" r="4"/>
  <path d="M23 21v-2a4 4 0 00-3-3.87"/>
  <path d="M16 3.13a4 4 0 010 7.75"/>
  <polyline points="9 13 12 16 22 6"/>
''')

icons['homework'] = svg_wrap('''
  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
  <line x1="8" y1="21" x2="16" y2="21"/>
  <line x1="12" y1="17" x2="12" y2="21"/>
  <polyline points="8 7 10 9 16 3"/>
''')

icons['question-bank'] = svg_wrap('''
  <circle cx="12" cy="12" r="10"/>
  <path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/>
  <line x1="12" y1="17" x2="12.01" y2="17"/>
''')

icons['exam-library'] = svg_wrap('''
  <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
  <polyline points="14 2 14 8 20 8"/>
  <line x1="16" y1="13" x2="8" y2="13"/>
  <line x1="16" y1="17" x2="8" y2="17"/>
  <polyline points="10 9 9 9 8 9"/>
''')

icons['assign-hw'] = svg_wrap('''
  <path d="M16 4h2a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h2"/>
  <rect x="8" y="2" width="8" height="4" rx="1" ry="1"/>
  <polyline points="9 13 11 15 15 11"/>
''')

icons['teaching-data'] = svg_wrap('''
  <line x1="18" y1="20" x2="18" y2="10"/>
  <line x1="12" y1="20" x2="12" y2="4"/>
  <line x1="6" y1="20" x2="6" y2="14"/>
  <polyline points="2 20 22 20"/>
''')

icons['learning-analytics'] = svg_wrap('''
  <path d="M21.21 15.89A10 10 0 118 2.83"/>
  <path d="M22 12A10 10 0 0012 2v10z"/>
''')

icons['growth-footprint'] = svg_wrap('''
  <path d="M12 20V10"/>
  <path d="M18 20V4"/>
  <path d="M6 20v-4"/>
  <circle cx="12" cy="8" r="2"/>
  <circle cx="18" cy="2" r="2"/>
  <circle cx="6" cy="14" r="2"/>
''')

icons['parent-comm'] = svg_wrap('''
  <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4-4v2"/>
  <circle cx="9" cy="7" r="4"/>
  <path d="M23 21v-2a4 4 0 00-3-3.87"/>
  <circle cx="19" cy="5" r="3"/>
  <path d="M19 8l-2 2"/>
''')

icons['parent-sign'] = svg_wrap('''
  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  <polyline points="9 12 11 14 15 10"/>
''')

icons['growth-care'] = svg_wrap('''
  <path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/>
  <circle cx="12" cy="12" r="1"/>
  <circle cx="12" cy="15" r="1"/>
''')

icons['personal-center'] = svg_wrap('''
  <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4-4v2"/>
  <circle cx="12" cy="7" r="4"/>
''')

icons['switch-class'] = svg_wrap('''
  <path d="M8 3H5a2 2 0 00-2 2v3"/>
  <path d="M21 8V5a2 2 0 00-2-2h-3"/>
  <path d="M3 16v3a2 2 0 002 2h3"/>
  <path d="M16 21h3a2 2 0 002-2v-3"/>
''')

icons['settings'] = svg_wrap('''
  <circle cx="12" cy="12" r="3"/>
  <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/>
''')

# ============ 顶部栏 icon（4个）============
icons['token'] = svg_wrap('''
  <circle cx="12" cy="12" r="10"/>
  <path d="M12 6v6l4 2"/>
''')

icons['notification'] = svg_wrap('''
  <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/>
  <path d="M13.73 21a2 2 0 01-3.46 0"/>
''')

icons['xiaowei'] = svg_wrap('''
  <circle cx="12" cy="10" r="6"/>
  <path d="M12 2a8 8 0 00-8 8c0 2.5 1.5 4.5 3 6l-1 4 4.5-2a8.2 8.2 0 005.5 0l4.5 2-1-4c1.5-1.5 3-3.5 3-6a8 8 0 00-8-8z"/>
  <circle cx="9" cy="9" r="1.5" fill="#F0A040" stroke="none"/>
  <circle cx="15" cy="9" r="1.5" fill="#F0A040" stroke="none"/>
  <path d="M9 13c.83.67 2 1 3 1s2.17-.33 3-1"/>
''')

icons['zhiliao'] = svg_wrap('''
  <ellipse cx="12" cy="10" rx="8" ry="6"/>
  <path d="M12 4v6"/>
  <path d="M12 20v-4"/>
  <path d="M8 8l2 2"/>
  <path d="M14 10l2-2"/>
  <ellipse cx="12" cy="20" rx="1.5" ry="1"/>
  <path d="M12 20c0 1 .75 1.5 1.5 1.5h-3c.75 0 1.5-.5 1.5-1.5"/>
''')

# ============ Dashboard 快捷操作（7个）============
icons['create-plan'] = svg_wrap('''
  <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
  <polyline points="14 2 14 8 20 8"/>
  <line x1="12" y1="18" x2="12" y2="12"/>
  <line x1="9" y1="15" x2="15" y2="15"/>
''')

icons['create-exercise'] = svg_wrap('''
  <path d="M12 20h9"/>
  <path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
  <line x1="12" y1="18" x2="12" y2="12"/>
''')

icons['create-exam'] = svg_wrap('''
  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
  <line x1="3" y1="9" x2="21" y2="9"/>
  <line x1="9" y1="21" x2="9" y2="9"/>
  <polyline points="15 14 13 12 15 10"/>
''')

icons['create-hw'] = svg_wrap('''
  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
  <line x1="8" y1="21" x2="16" y2="21"/>
  <line x1="12" y1="17" x2="12" y2="21"/>
  <line x1="12" y1="9" x2="12" y2="9"/>
  <line x1="12" y1="13" x2="12" y2="14"/>
''')

icons['create-illustration'] = svg_wrap('''
  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
  <circle cx="8.5" cy="8.5" r="1.5"/>
  <polyline points="21 15 16 10 5 21"/>
  <polygon points="10 14 13 11 17 14 10 14" fill="#F0A040" stroke="none" opacity="0.3"/>
''')

icons['create-audio'] = svg_wrap('''
  <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
  <path d="M15.54 8.46a5 5 0 010 7.07"/>
  <path d="M19.07 4.93a10 10 0 010 14.14"/>
''')

icons['create-video'] = svg_wrap('''
  <polygon points="23 7 16 12 23 17 23 7"/>
  <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
''')

# ============ 通用功能 icon（10个）============
icons['search'] = svg_wrap('''
  <circle cx="11" cy="11" r="8"/>
  <line x1="21" y1="21" x2="16.65" y2="16.65"/>
''')

icons['expand'] = svg_wrap('''
  <polyline points="15 3 21 3 21 9"/>
  <polyline points="9 21 3 21 3 15"/>
  <line x1="21" y1="3" x2="14" y2="10"/>
  <line x1="3" y1="21" x2="10" y2="14"/>
''')

icons['collapse'] = svg_wrap('''
  <polyline points="4 14 10 14 10 20"/>
  <polyline points="20 10 14 10 14 4"/>
  <line x1="10" y1="14" x2="4" y2="20"/>
  <line x1="14" y1="10" x2="20" y2="4"/>
''')

icons['edit'] = svg_wrap('''
  <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
  <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
''')

icons['delete'] = svg_wrap('''
  <polyline points="3 6 5 6 21 6"/>
  <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
''')

icons['preview'] = svg_wrap('''
  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
  <circle cx="12" cy="12" r="3"/>
''')

icons['publish'] = svg_wrap('''
  <path d="M22 2L11 13"/>
  <path d="M22 2l-7 20-4-9-9-4 20-7z"/>
''')

icons['save'] = svg_wrap('''
  <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
  <polyline points="17 21 17 13 7 13 7 21"/>
  <polyline points="7 3 7 8 15 8"/>
''')

icons['plus'] = svg_wrap('''
  <line x1="12" y1="5" x2="12" y2="19"/>
  <line x1="5" y1="12" x2="19" y2="12"/>
''')

icons['upload'] = svg_wrap('''
  <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
  <polyline points="17 8 12 3 7 8"/>
  <line x1="12" y1="3" x2="12" y2="15"/>
''')

# ============ 生成所有 icon ============
generated = []
for name, svg in icons.items():
    filename = write_icon(name, svg)
    generated.append(filename)

print(f"Generated {len(generated)} SVG icons in {ICON_DIR}")
for f in sorted(generated):
    path = os.path.join(ICON_DIR, f)
    size = os.path.getsize(path)
    print(f"  {f} ({size} bytes)")
