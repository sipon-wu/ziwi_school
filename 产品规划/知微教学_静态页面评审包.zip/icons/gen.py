import os

ICON_DIR = "/Users/sipon/CodeBuddy/AI教案/code/frontend/public/icons"
for f in os.listdir(ICON_DIR):
    if f.endswith('.svg'): os.remove(os.path.join(ICON_DIR, f))

S = 24
def svg(body, viewBox="0 0 24 24", color='#4A4A5A'):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{S}" height="{S}" viewBox="{viewBox}" fill="none" stroke="{color}" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">\n{body}\n</svg>'

def w(name, body, viewBox="0 0 24 24", color='#4A4A5A'):
    with open(os.path.join(ICON_DIR, f'{name}.svg'), 'w') as f:
        f.write(svg(body, viewBox, color))

# ── 统一视觉边界框：所有 icon 在 24x24 中居中，边界框约 16x18（纵向）或 16x16（方型）

# ════════════════════════════════════
#  侧边栏导航（21个）
# ════════════════════════════════════

# 首页 - 房子，边界框约 16x16
w('nav-home', '<path d="M4 10L12 3L20 10V20C20 20.5 19.5 21 19 21H5C4.5 21 4 20.5 4 20V10Z"/><path d="M9 21V13H15V21"/>')

# 教学备课 - 打开的书，边界框约 16x18
w('nav-prep', '<path d="M4 20H18"/><path d="M4 4C4 3 5 2 6 2H18V20H6C5 20 4 19 4 18V4Z"/><line x1="8" y1="7" x2="14" y2="7"/><line x1="8" y1="11" x2="12" y2="11"/>')

# 教案草稿箱 - 文档+横线，边界框约 14x16（w=14, h=16，居中）
w('nav-draft', '<rect x="5" y="4" width="14" height="16" rx="2"/><line x1="8" y1="9" x2="16" y2="9"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="12" y2="17"/>')

# 教案发布库 - 文件夹，边界框约 16x14
w('nav-published', '<path d="M20 19C20 19.5 19.5 20 19 20H5C4.5 20 4 19.5 4 19V7C4 6.5 4.5 6 5 6H9L11 8H19C19.5 8 20 8.5 20 9V19Z"/>')

# 素材库 - 四宫格，边界框约 14x14
w('nav-material', '<rect x="5" y="5" width="6" height="6" rx="1"/><rect x="13" y="5" width="6" height="6" rx="1"/><rect x="5" y="13" width="6" height="6" rx="1"/><rect x="13" y="13" width="6" height="6" rx="1"/>')

# 教案互审 - 文档+对勾，边界框约 14x16
w('nav-review', '<rect x="5" y="4" width="14" height="16" rx="2"/><polyline points="8 12 11 15 16 10"/>')

# 作业练习 - 文件+对勾，边界框约 14x16
w('nav-hw', '<rect x="5" y="4" width="14" height="16" rx="2"/><polyline points="8 12 11 15 16 10"/>')

# 出题题库 - 问号圆圈，边界框约 16x16
w('nav-question', '<circle cx="12" cy="12" r="7"/><path d="M10 10C10 9 11 8 12 8C13 8 14 9 14 10C14 11 13 12 12 12V13"/><circle cx="12" cy="16" r="0.8" fill="#4A4A5A" stroke="none"/>')

# 组卷试卷库 - 三栏表格，边界框约 16x16
w('nav-exam', '<rect x="4" y="4" width="16" height="16" rx="2"/><line x1="4" y1="10" x2="20" y2="10"/><line x1="10" y1="10" x2="10" y2="20"/><line x1="14" y1="14" x2="16" y2="14"/><line x1="14" y1="17" x2="16" y2="17"/>')

# 作业布置 - 文件+笔，边界框约 14x16
w('nav-assign', '<rect x="5" y="4" width="14" height="16" rx="2"/><path d="M15 8L10 13L9 15L11 14L16 9"/>')

# 教学数据 - 柱状图，边界框约 16x16
w('nav-data', '<line x1="18" y1="20" x2="18" y2="12"/><line x1="12" y1="20" x2="12" y2="8"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="4" y1="20" x2="20" y2="20"/>')

# 学情分析 - 饼图，边界框约 16x16
w('nav-analytics', '<circle cx="12" cy="12" r="7"/><path d="M12 5V12L16 16"/>')

# 成长足迹 - 上升趋势，边界框约 16x16
w('nav-growth', '<polyline points="5 16 9 12 13 14 19 8"/><circle cx="19" cy="8" r="1.5"/><line x1="4" y1="20" x2="20" y2="20"/>')

# 家校沟通 - 对话气泡，边界框约 16x14
w('nav-parent', '<path d="M20 16C20 16.5 19.5 17 19 17H7L4 20V7C4 6.5 4.5 6 5 6H19C19.5 6 20 6.5 20 7V16Z"/><line x1="8" y1="10" x2="16" y2="10"/><line x1="8" y1="13" x2="12" y2="13"/>')

# 家长签字 - 盾牌+对勾，边界框约 16x16
w('nav-sign', '<path d="M12 21C12 21 18 17 18 11V6C18 5.5 17.5 5 17 5H7C6.5 5 6 5.5 6 6V11C6 17 12 21 12 21Z"/><polyline points="9 12 11.5 14.5 15 10"/>')

# 成长关爱 - 心形，边界框约 16x16
w('nav-care', '<path d="M12 19C12 19 19 14.5 19 9.5C19 6.5 16.5 5 14 5C12.5 5 11.5 5.5 11 6.5C10.5 5.5 9.5 5 8 5C5.5 5 3 6.5 3 9.5C3 14.5 10 19 12 19Z"/>')

# 个人中心 - 人像，边界框约 14x16（闭合，无开口）
w('nav-user', '<circle cx="12" cy="8" r="4"/><path d="M6 20C6 17 9 15 12 15C15 15 18 17 18 20"/>')

# 班级切换 - 双向箭头，边界框约 16x14
w('nav-switch', '<polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/>')

# 系统设置 - 齿轮，边界框约 16x16
w('nav-settings', '<circle cx="12" cy="12" r="4"/><path d="M12 5V7"/><path d="M12 17V19"/><path d="M5 12H7"/><path d="M17 12H19"/><path d="M7.05 7.05L8.46 8.46"/><path d="M15.54 15.54L16.95 16.95"/><path d="M7.05 16.95L8.46 15.54"/><path d="M15.54 8.46L16.95 7.05"/>')

# 侧栏收起 - 箭头左，边界框约 16x16
w('nav-collapse', '<rect x="4" y="4" width="16" height="16" rx="2"/><line x1="9" y1="4" x2="9" y2="20"/><polyline points="13 8 9 12 13 16"/>')

# 侧栏展开 - 箭头右，边界框约 16x16
w('nav-expand', '<rect x="4" y="4" width="16" height="16" rx="2"/><line x1="9" y1="4" x2="9" y2="20"/><polyline points="11 8 15 12 11 16"/>')

# ════════════════════════════════════
#  方向箭头（3个）
# ════════════════════════════════════
w('arrow-left', '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>')
w('arrow-down', '<polyline points="6 9 12 15 18 9"/>')
w('arrow-right', '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>')

# ════════════════════════════════════
#  顶部栏（3个）
# ════════════════════════════════════
w('topbar-token', '<circle cx="12" cy="12" r="7"/><path d="M12 7V12L15 14"/>')
w('topbar-notify', '<path d="M18 8A6 6 0 006 8C6 14 3 16 3 16H21C21 16 18 14 18 8Z"/><path d="M10.5 21C10.5 21.8 11.2 22.5 12 22.5C12.8 22.5 13.5 21.8 13.5 21"/>')
w('topbar-xiaowei', '<circle cx="12" cy="8" r="5"/><path d="M7 16C9 18 15 18 17 16"/><path d="M8 20C9 21 15 21 16 20"/>')

# ════════════════════════════════════
#  新建创作 7入口（7个）
# ════════════════════════════════════
w('create-plan', '<rect x="5" y="4" width="14" height="16" rx="2"/><line x1="8" y1="9" x2="16" y2="9"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="12" y2="17"/>')
w('create-exercise', '<circle cx="12" cy="12" r="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="12" y1="8" x2="12" y2="16"/>')
w('create-exam', '<rect x="4" y="4" width="16" height="16" rx="2"/><line x1="4" y1="10" x2="20" y2="10"/><line x1="10" y1="10" x2="10" y2="20"/>')
w('create-hw', '<rect x="5" y="4" width="14" height="16" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>')
w('create-image', '<rect x="4" y="4" width="16" height="16" rx="2"/><circle cx="9" cy="9" r="1.5"/><polyline points="20 15 15 10 6 19"/>')
w('create-audio', '<path d="M3 16V14C3 9.5 6 7 12 7C18 7 21 9.5 21 14V16"/><rect x="5" y="15" width="5" height="5" rx="1"/><rect x="14" y="15" width="5" height="5" rx="1"/>')
w('create-video', '<rect x="2" y="5" width="14" height="14" rx="2"/><polygon points="21 7 16 12 21 17"/>')

# ════════════════════════════════════
#  通用操作（15个）
# ════════════════════════════════════
w('edit', '<path d="M14 4L20 10L10 20L4 20L4 14L14 4Z"/>')
w('delete', '<path d="M10 5V7M14 5V7"/><line x1="6" y1="7" x2="18" y2="7"/><rect x="8" y="7" width="8" height="13" rx="1"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>')
w('copy', '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4C4 15 3 14.5 3 14V5C3 4.5 3.5 4 4 4H13C13.5 4 14 4.5 14 5V6"/>')
w('save', '<path d="M19 21H5C4.5 21 4 20.5 4 20V5C4 4.5 4.5 4 5 4H15L20 9V20C20 20.5 19.5 21 19 21Z"/><line x1="8" y1="21" x2="8" y2="13"/><line x1="16" y1="21" x2="16" y2="13"/><line x1="8" y1="13" x2="16" y2="13"/>')
w('preview', '<path d="M1 12C1 12 5 5 12 5C19 5 23 12 23 12C23 12 19 19 12 19C5 19 1 12 1 12Z"/><circle cx="12" cy="12" r="3"/>')
w('publish', '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9"/>')
w('plus', '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>')
w('close', '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>')
w('search', '<circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>')
w('filter', '<polygon points="22 3 2 3 10 12.5 10 19 14 21 14 12.5 22 3"/>')
w('upload', '<path d="M21 15V19C21 19.5 20.5 20 20 20H4C3.5 20 3 19.5 3 19V15"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>')
w('more', '<circle cx="5" cy="12" r="1.5" fill="#4A4A5A" stroke="none"/><circle cx="12" cy="12" r="1.5" fill="#4A4A5A" stroke="none"/><circle cx="19" cy="12" r="1.5" fill="#4A4A5A" stroke="none"/>')
w('refresh', '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3 9C5 6 8 4 12 4C16 4 19 6 21 9"/>')
w('share', '<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><line x1="8.5" y1="13" x2="15.5" y2="17.5"/><line x1="15.5" y1="6.5" x2="8.5" y2="10.5"/>')
w('download', '<path d="M21 15V19C21 19.5 20.5 20 20 20H4C3.5 20 3 19.5 3 19V15"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>')

# ════════════════════════════════════
#  其他（6个）
# ════════════════════════════════════
w('comment', '<path d="M21 15C21 15.5 20.5 16 20 16H7L3 20V6C3 5.5 3.5 5 4 5H20C20.5 5 21 5.5 21 6V15Z"/><line x1="8" y1="9" x2="16" y2="9"/><line x1="8" y1="12" x2="13" y2="12"/>')
w('link', '<path d="M10 13C10 13 12 15 15 15L17 13C19 11 19 9 17 7L15 5C13 3 11 3 9 5"/><path d="M14 11C14 11 12 9 9 9L7 11C5 13 5 15 7 17L9 19C11 21 13 21 15 19"/>')
w('drag', '<circle cx="9" cy="5" r="1.2" fill="#999" stroke="none"/><circle cx="15" cy="5" r="1.2" fill="#999" stroke="none"/><circle cx="9" cy="12" r="1.2" fill="#999" stroke="none"/><circle cx="15" cy="12" r="1.2" fill="#999" stroke="none"/><circle cx="9" cy="19" r="1.2" fill="#999" stroke="none"/><circle cx="15" cy="19" r="1.2" fill="#999" stroke="none"/>')
w('print', '<path d="M6 9V3H18V9"/><path d="M4 12H20V19C20 19.5 19.5 20 19 20H5C4.5 20 4 19.5 4 19V12Z"/><line x1="8" y1="14" x2="16" y2="14"/><line x1="8" y1="17" x2="16" y2="17"/>')
w('history', '<circle cx="12" cy="12" r="7"/><polyline points="12 7 12 12 15 14"/><polyline points="3 4 7 4 8 6"/>')
w('report', '<rect x="5" y="4" width="14" height="16" rx="2"/><line x1="8" y1="9" x2="16" y2="9"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="12" y2="17"/>')

# ════════════════════════════════════
#  状态标记（6个）
# ════════════════════════════════════
w('approve', '<polyline points="20 6 9 17 4 12"/>')
w('reject', '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>')
w('check-circle', '<circle cx="12" cy="12" r="7"/><polyline points="16 10 11 15 8 12"/>')
w('warning', '<path d="M10.5 3.5L2.5 17.5C2 18.5 2.5 20 4 20H20C21.5 20 22 18.5 21.5 17.5L13.5 3.5C13 2.5 11 2.5 10.5 3.5Z" stroke="#FAAD14"/><line x1="12" y1="9" x2="12" y2="13" stroke="#FAAD14"/><line x1="12" y1="16" x2="12" y2="16" stroke="#FAAD14"/>')
w('help', '<circle cx="12" cy="12" r="7"/><path d="M10 10C10 9 11 8 12 8C13 8 14 9 14 10C14 11 13 12 12 12V13"/><circle cx="12" cy="16" r="0.8" fill="#4A4A5A" stroke="none"/>')
w('sparkle', '<path d="M12 4L13 8L17 9L13 10L12 14L11 10L7 9L11 8Z" stroke="#8B5CF6"/><circle cx="6" cy="6" r="1" fill="#8B5CF6" stroke="none"/><circle cx="18" cy="18" r="1" fill="#8B5CF6" stroke="none"/>')

# ════════════════════════════════════
#  知识图谱视图（3个）
# ════════════════════════════════════
w('graph-tree', '<circle cx="12" cy="5" r="2"/><circle cx="6" cy="12" r="2"/><circle cx="18" cy="12" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/><line x1="12" y1="7" x2="6" y2="10"/><line x1="12" y1="7" x2="18" y2="10"/><line x1="6" y1="14" x2="6" y2="17"/><line x1="18" y1="14" x2="18" y2="17"/>')
w('graph-spiral', '<path d="M12 4C16 4 19 7 19 11C19 15 16 18 12 18"/><circle cx="12" cy="4" r="1.5" fill="#4A4A5A" stroke="none"/><circle cx="19" cy="11" r="1.5" fill="#4A4A5A" stroke="none"/><circle cx="12" cy="18" r="1.5" fill="#4A4A5A" stroke="none"/>')
w('graph-mesh', '<circle cx="12" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><line x1="12" y1="7" x2="5" y2="17"/><line x1="5" y1="18" x2="19" y2="18"/><line x1="19" y1="17" x2="12" y2="7"/>')

# ════════════════════════════════════
#  微距（额外）
# ════════════════════════════════════
w('check-square', '<rect x="4" y="4" width="16" height="16" rx="2"/><polyline points="9 12 11 14 15 10"/>')
w('send', '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9"/>')

print(f"Generated {len(os.listdir(ICON_DIR))} icons")
